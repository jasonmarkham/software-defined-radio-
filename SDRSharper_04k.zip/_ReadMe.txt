This modification was created to support ExtIO based SDR hardware on lower HF.
Which was (and maybe still is) not possible using the original SDRSharp app.

Get SDRSharper_02g.zip and unpack/unzip files into a single destination folder.

See also Help.txt file included in the Zip-file or click [?] button on bottom right of SDR.

SDRSharper Requires Microsoft .Net framework 3.5
http://www.microsoft.com/en-us/download/details.aspx?id=21

On most modern W7 and above systems already available.
Although on W10 you will have to download it again.

SDRSharper supports most ExtIO enabled SDR hardware front ends.
See lowerr list on http://www.hdsdr.de/hardware.html
Place appropriate ExtIO*.dll file in your SDRSharper folder.

Package already contains ExtIO dll's for Perseus and PapRadio SDR.
Furthermore the RTLSDR DVBT Dongle is supported.


To contact author: l_o_n_g_d_i_p_o_l_e_[at]_gmx.com	(without the _ char's and @ for [at])

- use ExtIO_PappRadio.zip for pappradio ExtIO files.
- use ExtIO_PappRadio2.zip for pappradio v2 (usb) ExtIO files.
- use ExtIO_Perseus.zip for Perseus ExtIO files.
- use ExtIO_PMSDR_XP.zip for PMSDR ExtIO files running windows-XP.
- use ExtIO_PMSDR_W7.zip for PMSDR ExtIO files running windows-7.
- use ExtIO_SI570.zip for PMSDR, FiFiSDR or other SI570 based hardware.
- use Install_CFGSR_v2.6.msi to instaal full SI570 package including drivers.

============================================================================================
Release notes:
============================================================================================

mar 04, 2015 - version 0.2g

- Added Synchronous AM demodulation.
- Both mono and 'pseudo stereo'. 
- Removed trial period restrictions.
- Minor fixes.

feb 15, 2015 - Version 0.2g

- Bugfix on RTL-USB selection
- Synchronous AM (SAM) demodulation added
- Some other minor improvements

oct 2014 - version 0.2e

- Fixed crash when using soundcard based ExtIO hardware.
- Fixed display of spurs when playing sim.wav (http://www.sm5bsz.com/lir/sim1/sim1.htm)
- Bugfix when using a system with sound input disabled.
- Added separate IF baseband spectrum display.
- Enabled zooming and tuning for wide spectrum recordings.
- Adressed some (minor) performance issues.
- Removed center frequency indicator.

(and probably introduced some new ones..., if so let me know).
